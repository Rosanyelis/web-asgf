<footer id="footer" class="footer">
                <div class="container">
                    <div class="row-base row">
                        <div class="col-base text-left-md col-md-6">
                            <a href="{{ url('/') }}" class="brand">
                                <img class="brand-logo" src="{{ asset('img/ASG-logo.webp') }}" alt="logo">
                            </a>
                        </div>

                        <div class="text-right-md col-base col-md-6">
                            © Advanced Systems Group 2023. All Rights Reserved.
                        </div>
                    </div>
                </div>
            </footer>
